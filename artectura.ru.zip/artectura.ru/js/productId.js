	
if(document.readyState == 'loading'){
		document.addEventListener('DOMContentLoaded', ready);
	} else {
		ready();
	}


function ready(){
	if(new URLSearchParams(window.location.search).get('id') == '002'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 1);
	}

	else if(new URLSearchParams(window.location.search).get('id') == '005'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 1);
	}
	else if(new URLSearchParams(window.location.search).get('id') == '004'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 3);
	}

	else if(new URLSearchParams(window.location.search).get('id') == '13'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 5);
	}
	else if(new URLSearchParams(window.location.search).get('id') == '14'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 6);
	}
	else if(new URLSearchParams(window.location.search).get('id') == '15'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 8);
	}
	else if(new URLSearchParams(window.location.search).get('id') == '16'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 7);
	}


	else if(new URLSearchParams(window.location.search).get('id') == '55'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 0);
	}
	else if(new URLSearchParams(window.location.search).get('id') == '56'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 4);
	}
	else if(new URLSearchParams(window.location.search).get('id') == '57'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 2);
	}

	else if (new URLSearchParams(window.location.search).get('id') == '60'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 4);
	}
	else if (new URLSearchParams(window.location.search).get('id') == '61'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 5);
	}
	else if (new URLSearchParams(window.location.search).get('id') == '62'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 6);
	}
	else if (new URLSearchParams(window.location.search).get('id') == '63'){
		// Get a reference to the carousel element
		var carousel = $('.owl-carousel');

		// Go to the second slide (index 1)
		carousel.trigger('to.owl.carousel', 7);
	}
}
