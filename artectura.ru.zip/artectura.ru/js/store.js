if (navigator.userAgent.indexOf("Firefox") != -1) {

if(document.readyState == 'loading'){
	document.addEventListener('DOMContentLoaded', ready);
} else {
	ready();
}

function ready(){
	populateCart();
	updateCartTotal();
	isZeroItems();

	var removeCartItemButtons = document.getElementsByClassName('btn-danger');
	for (var i = 0; i<removeCartItemButtons.length; i++){
		var button = removeCartItemButtons[i];
		button.addEventListener('click', removeCartItemReturn(button));
	}
	
	var quantityInputs = document.getElementsByClassName('cart-row');
	for (var i = 0; i < quantityInputs.length; i++) {
	  var button = quantityInputs[i];
	  button.addEventListener('change', quantityChangedReturn(button));
	}
	
}

//removes item from sessionStorage
function removeCartItemReturn(button){
	return function removeCartItem(event){
		var buttonClicked = event.target;
		buttonClicked.parentElement.parentElement.remove();

		var shoppingCart = JSON.parse(sessionStorage.getItem("cart")) || {};
		var productElement = button.closest('.cart-row').querySelector('.product-grid');
		var productImage = productElement.style.backgroundImage.slice(5, -2);

		var matchingKey;
		for (var key in shoppingCart) {
		  if (shoppingCart.hasOwnProperty(key)) {
		    if (shoppingCart[key].image === productImage) {
		      matchingKey = key;
		      break;
			}
	      }
	    } 
		var productId = matchingKey;
		delete shoppingCart[productId];
		sessionStorage.setItem("cart", JSON.stringify(shoppingCart));

		location.reload(true);
		updateCartTotal();
		isZeroItems();

	}
}

//changes quantity of an item in local storage
function quantityChangedReturn(button){
	return function quantityChanged(event){
		var input = event.target;
		if (isNaN(input.value) || input.value <= 0){
			input.value = 1;
		}
		var shoppingCart = JSON.parse(sessionStorage.getItem("cart")) || {};
		var productElement = button.closest('.cart-row').querySelector('.product-grid');
		var productImage = productElement.style.backgroundImage.slice(5, -2);

		var matchingKey;
		for (var key in shoppingCart) {
		  if (shoppingCart.hasOwnProperty(key)) {
		    if (shoppingCart[key].image === productImage) {
		      matchingKey = key;
		      break;
			}
	      }
	    } 
		var productId = matchingKey;
		shoppingCart[productId].quantity = input.value;
		sessionStorage.setItem("cart", JSON.stringify(shoppingCart));
		updateCartTotal();
	}
}

//updates cart total
function updateCartTotal(){
	var total = 0;
	let shoppingCart = JSON.parse(sessionStorage.getItem("cart")) || {};
	for (var productId in shoppingCart) {
		var product = shoppingCart[productId];
		var price = product.price;
		var quantity = product.quantity;
		total = total + (price * quantity);
	}
	total = Math.round(total * 100) / 100;
	document.getElementsByClassName('cart-total-price')[0].innerText = total + ' руб.';
}

//checks if there are no items in cart and changes the 2n section of <main>
function isZeroItems(){
	var totalPrice = document.getElementsByClassName('cart-total-price')[0].innerText;
	if (totalPrice == 0 + ' руб.'){
		document.getElementById('cart_items').remove();
		document.getElementsByClassName('also-bought')[0].innerText = "Многие покупают";
	}
}

//adds items added to sessionStorage to cart
function populateCart() {
    var shoppingCart = JSON.parse(sessionStorage.getItem("cart"));
    var cartHTML = "";
    if (shoppingCart) {
	    Object.values(shoppingCart).forEach(product => {
	      cartHTML += `
	        <tr class="cart-row">
	          <td  style="width: 250px">
	            <div class="product" style="margin-bottom:0px;">
					<a href="${product.path}"><div class="product-grid" style="background-image:url(${product.image}); width: 200px; height: 200px"></div></a>
					<div class="desc">
						<h3 style="width: 200px; text-align: center;"><a href="${product.path}">${product.name}</a></h3>
					</div>
				</div>
	          </td>
	          <td><input type="number" class="form-control" value="${product.quantity}" min="1"></td>
	          <td class="cart-price">${product.price} руб.</td>
	          <td><button class="btn-danger">Убрать</button></td>
	        </tr>
	      `;
	    });
    }
    document.querySelector(".cart-items").innerHTML = cartHTML;

}

}

else
{

	if(document.readyState == 'loading'){
	document.addEventListener('DOMContentLoaded', ready);
	} else {
		ready();
	}


	function ready(){
		populateCart();
		updateCartTotal();
		isZeroItems();

		var removeCartItemButtons = document.getElementsByClassName('btn-danger');
		for (var i = 0; i<removeCartItemButtons.length; i++){
			var button = removeCartItemButtons[i];
			button.addEventListener('click', removeCartItemReturn(button));
		}
		
		var quantityInputs = document.getElementsByClassName('cart-row');
		for (var i = 0; i < quantityInputs.length; i++) {
		  var button = quantityInputs[i];
		  button.addEventListener('change', quantityChangedReturn(button));
		}
	
	}

//removes item from localstorage
function removeCartItemReturn(button){
	return function removeCartItem(event){
		var buttonClicked = event.target;
		buttonClicked.parentElement.parentElement.remove();

		var shoppingCart = JSON.parse(localStorage.getItem("cart")) || {};
		var productElement = button.closest('.cart-row').querySelector('.product-grid');
		var productImage = productElement.style.backgroundImage.slice(5, -2);

		var matchingKey;
		for (var key in shoppingCart) {
		  if (shoppingCart.hasOwnProperty(key)) {
		    if (shoppingCart[key].image === productImage) {
		      matchingKey = key;
		      break;
			}
	      }
	    } 
		var productId = matchingKey;
		delete shoppingCart[productId];
		localStorage.setItem("cart", JSON.stringify(shoppingCart));

		location.reload(true);
		updateCartTotal();
		isZeroItems();

	}
}

//changes quantity of an item in local storage
function quantityChangedReturn(button){
	return function quantityChanged(event){
		var input = event.target;
		if (isNaN(input.value) || input.value <= 0){
			input.value = 1;
		}
		var shoppingCart = JSON.parse(localStorage.getItem("cart")) || {};
		var productElement = button.closest('.cart-row').querySelector('.product-grid');
		var productImage = productElement.style.backgroundImage.slice(5, -2);

		var matchingKey;
		for (var key in shoppingCart) {
		  if (shoppingCart.hasOwnProperty(key)) {
		    if (shoppingCart[key].image === productImage) {
		      matchingKey = key;
		      break;
			}
	      }
	    } 
		var productId = matchingKey;
		shoppingCart[productId].quantity = input.value;
		localStorage.setItem("cart", JSON.stringify(shoppingCart));
		updateCartTotal();
	}
}

//updates cart total
function updateCartTotal(){
	var total = 0;
	let shoppingCart = JSON.parse(localStorage.getItem("cart")) || {};
	for (var productId in shoppingCart) {
		var product = shoppingCart[productId];
		var price = product.price;
		var quantity = product.quantity;
		total = total + (price * quantity);
	}
	total = Math.round(total * 100) / 100;
	document.getElementsByClassName('cart-total-price')[0].innerText = total + ' руб.';
}

//checks if there are no items in cart and changes the 2n section of <main>
function isZeroItems(){
	var totalPrice = document.getElementsByClassName('cart-total-price')[0].innerText;
	if (totalPrice == 0 + ' руб.'){
		document.getElementById('cart_items').remove();
		document.getElementsByClassName('also-bought')[0].innerText = "Многие покупают";
	}
}

//adds items added to localStorage to cart
function populateCart() {
    var shoppingCart = JSON.parse(localStorage.getItem("cart"));
    var cartHTML = "";
    if (shoppingCart) {
	    Object.values(shoppingCart).forEach(product => {
	      cartHTML += `
	        <tr class="cart-row">
	          <td  style="width: 250px">
	            <div class="product" style="margin-bottom:0px;">
					<a href="${product.path}"><div class="product-grid" style="background-image:url(${product.image}); width: 200px; height: 200px"></div></a>
					<div class="desc">
						<h3 style="width: 200px; text-align: center;"><a href="${product.path}">${product.name}</a></h3>
					</div>
				</div>
	          </td>
	          <td><input type="number" class="form-control" value="${product.quantity}" min="1"></td>
	          <td class="cart-price">${product.price} руб.</td>
	          <td><button class="btn-danger">Убрать</button></td>
	        </tr>
	      `;
	    });
    }
    document.querySelector(".cart-items").innerHTML = cartHTML;

}
}