if(document.readyState == 'loading'){
    document.addEventListener('DOMContentLoaded', ready);
} else {
    ready();
}

var isPhone = false;
if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
   isPhone = true;
}

var bottomPosition1 = document.getElementById("fh5co-product").offsetTop + document.getElementById("fh5co-product").offsetHeight;

function ready(){
    var emailForm = document.getElementById("fh5co-started");
    if (isPhone) {
      emailForm.style.marginTop = "350px"
      document.getElementById("width-set").style.width = "100%"
    } else {
      emailForm.style.marginTop = "250px"
    }


    addReviews();


    var inputButton = document.getElementById("rating-input");
    inputButton.addEventListener('change', quantityChanged);

}

function quantityChanged(event){
    var input = event.target;
    if (isNaN(input.value) || input.value < 1 || input.value > 5){
      input.value = 5;
    }
  }




function addReviews(event){

      const urlParams = new URLSearchParams(window.location.search);
      var productId = urlParams.get('id');

      if (productId==='002'){
        productId='001';
      }
      else if(productId=='004' || productId=='005'){
        productId='003';
      }
      else if(productId=='007'||productId=='008'||productId=='009'||productId=='10'||productId=='11'){
        productId='006';
      }
      else if(productId=='13'||productId=='14'||productId=='15'||productId=='16'){
        productId='12';
      }
      else if(productId=='18'||productId=='19'){
        productId='17';
      }
      else if(productId=='21'||productId=='22'||productId=='23'){
        productId='20';
      }
      else if(productId=='24'||productId=='25'||productId=='26'||productId=='27'||productId=='28'){
        productId='24';
      }
      else if(productId=='30'||productId=='31'||productId=='32'||productId=='33'){
        productId='29';
      }
      else if(productId=='35'||productId=='36'||productId=='37'){
        productId='34';
      }
      else if(productId=='39'||productId=='40'||productId=='41'){
        productId='38';
      }
      else if(productId=='56'||productId=='57'){
        productId='55';
      }
      else if(productId=='60'||productId=='61'||productId=='62'){
        productId='59';
      }


      emailForm = document.getElementById("fh5co-started");
      var link = document.createElement("a");
      link.href = `reviews.html?id=${productId}`;
      var button = document.getElementById('expand-reviews');
      link.appendChild(button);
      var center = document.getElementById('btn-center');
      center.appendChild(link);
}