if (navigator.userAgent.indexOf("Firefox") != -1) {

if(document.readyState == 'loading'){
	document.addEventListener('DOMContentLoaded', ready);
} else {
	ready();
}

function ready(){
	
	updateCartTotal();
	
}

//updates cart total
function updateCartTotal(){
	var total = 0;
	let shoppingCart = JSON.parse(sessionStorage.getItem("cart")) || {};
	for (var productId in shoppingCart) {
		var product = shoppingCart[productId];
		var price = product.price;
		var quantity = product.quantity;
		total = total + (price * quantity);
	}
	total = Math.round(total * 100) / 100;
	document.getElementsByClassName('cart-total-price')[0].innerText = total + ' руб.';
}


}

else
{

	if(document.readyState == 'loading'){
	document.addEventListener('DOMContentLoaded', ready);
	} else {
		ready();
	}


	function ready(){
		updateCartTotal();
	
	}

//updates cart total
function updateCartTotal(){
	var total = 0;
	let shoppingCart = JSON.parse(localStorage.getItem("cart")) || {};
	for (var productId in shoppingCart) {
		var product = shoppingCart[productId];
		var price = product.price;
		var quantity = product.quantity;
		total = total + (price * quantity);
	}
	total = Math.round(total * 100) / 100;
	document.getElementsByClassName('cart-total-price')[0].innerText = total + ' руб.';
}
}